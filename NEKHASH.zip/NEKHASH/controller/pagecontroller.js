
  app.controller('PageCtrl', function ($scope, $location, $http) {
    console.log("Page Controller reporting for duty.");
  
    // Activates the Carousel
    $('.carousel').carousel({
      interval: 5000
    });

});