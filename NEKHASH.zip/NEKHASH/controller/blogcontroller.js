app.controller('BlogCtrl', function ($scope, $location, $http) {
    console.log("Blog Controller reporting for duty.");
  });
  